
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";

export default function ArtStore() {
  const [cart, setCart] = useState([]);

  const artPieces = [
    { id: 1, title: "Snake", price: 30, image: "/snake.jpg" },
    { id: 2, title: "Two Fighting Dragons", price: 50, image: "/fightingdragons.jpg" },
  ];

  const addToCart = (item) => {
    setCart([...cart, item]);
  };

  return (
    <div className="p-6 max-w-5xl mx-auto">
      <h1 className="text-4xl font-bold text-center mb-8">🎨 DoodleBlade Industries™</h1>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {artPieces.map((art) => (
          <Card key={art.id} className="rounded-2xl shadow-xl">
            <img src={art.image} alt={art.title} className="rounded-t-2xl w-full h-60 object-cover" />
            <CardContent className="p-4">
              <h2 className="text-xl font-semibold">{art.title}</h2>
              <p className="text-lg text-gray-600">${art.price}</p>
              <Button className="mt-4 w-full" onClick={() => addToCart(art)}>
                Add to Cart
              </Button>
            </CardContent>
          </Card>
        ))}
      </div>
      <div className="mt-10 bg-gray-100 p-6 rounded-2xl">
        <h2 className="text-2xl font-bold mb-4">🧺 Your Cart</h2>
        {cart.length === 0 ? (
          <p className="text-gray-600">Your cart is empty, start adding some art!</p>
        ) : (
          <ul className="space-y-2">
            {cart.map((item, idx) => (
              <li key={idx} className="flex justify-between">
                <span>{item.title}</span>
                <span>${item.price}</span>
              </li>
            ))}
          </ul>
        )}
      </div>
    </div>
  );
}
